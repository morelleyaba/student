

<?php include("inc/header.php") ?>


<br><br>
     <div class="container row d-flex flex-row justify-content-center p-10">

  <div class="admin-form shadow p-4">

	<div class=" card bg-light">
	<div class="card-body text center">
		<div class="card-text">
			<h2>
	<?php echo"Vous avez deja signé votre presence aujourd'huit, Vous n'etes plus autorisé a signer une seconde fois ";?>
	<br><br>
	<a href="attendance.php" class="btn btn-primary pl-10">ok</a>
	</h1>
    </div>
    </div>
  
    </div>
    </div>
    </div>


<br><br>

<?php include("inc/footer.php") ?>